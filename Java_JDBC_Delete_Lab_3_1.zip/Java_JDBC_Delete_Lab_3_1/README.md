# OOPS Through Java Lab 3.1 — Delete Data Using JDBC

## AIM
Connect to MySQL using JDBC and delete a record from the `users` table with a `PreparedStatement` and a `WHERE` condition.

## File
- `JDBCDeleteDemo.java` — Java JDBC delete program

## Before running
1. Start MySQL Server.
2. Make sure the `mydatabase` database and `users` table exist, with an `id` column.
3. Update `USERNAME` and `PASSWORD` in the Java file.
4. Add MySQL Connector/J to your Java project's dependencies/classpath.
5. The program deletes the row whose ID is `2`. Make sure you intend to delete that record before running it.

## Compile and run
Replace `/path/to/mysql-connector-j.jar` with the actual path to your MySQL Connector/J JAR.

macOS/Linux:
```bash
javac -cp .:/path/to/mysql-connector-j.jar JDBCDeleteDemo.java
java -cp .:/path/to/mysql-connector-j.jar JDBCDeleteDemo
```

Windows:
```bat
javac -cp .;C:\path\to\mysql-connector-j.jar JDBCDeleteDemo.java
java -cp .;C:\path\to\mysql-connector-j.jar JDBCDeleteDemo
```

## Example output
If user ID 2 exists:
```text
Row deleted successfully.
```

If user ID 2 does not exist:
```text
No rows were deleted.
```

## Algorithm
1. Import JDBC classes.
2. Define the JDBC URL, username, and password.
3. Connect to `mydatabase` using try-with-resources.
4. Prepare `DELETE FROM users WHERE id = ?`.
5. Set the parameter to user ID `2`.
6. Execute the query using `executeUpdate()`.
7. Display a message based on the number of rows deleted.
8. Handle `SQLException`; try-with-resources closes resources automatically.
